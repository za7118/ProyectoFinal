<?php 
class Sistema extends CI_controller{
	//Función encargada de mostrar el Login para acceder al sistema
	public function index()
	{
      $this->load->view('login');
	}

	public function padre(){
    $this->load->view('padres/headerpapas');
	$this->load->view('padres/datosalumno');
	$this->load->view('padres/indexpadres');
	$this->load->view('padres/footer');
	}

	public function maestra(){
    $this->load->view('Maestras/headermaestras');
	$this->load->view('Maestras/datosmaestra');
	$this->load->view('Maestras/indexmaestras');
	$this->load->view('Maestras/footer');
	}

	public function directora(){
    $this->load->view('Directora/header');
	$this->load->view('Directora/datosdirectora');
	$this->load->view('Directora/indexdirectora');
	$this->load->view('Directora/footer');
	}
	
public function Nuevomaestro(){
	$this->load->view('Directora/header');
	$this->load->view('Directora/datosdirectora');
	$this->load->view('Directora/agregarmaestro');
	$this->load->view('Directora/footer');
	}
	public function Eliminarmaestro(){
		$this->load->view('Directora/header');
	$this->load->view('Directora/datosdirectora');
	 $this->load->view('Directora/eliminarmaestro');
	$this->load->view('Directora/footer');
	}
	public function Modificarmaestro(){
		$this->load->view('Directora/header');
	$this->load->view('Directora/datosdirectora');
	$this->load->view('Directora/modificarmaestro');
	$this->load->view('Directora/footer');
	}


	public function Nuevoalumno(){
		$this->load->view('Maestras/headermaestras');
	$this->load->view('Maestras/datosmaestra');
	$this->load->view('Maestras/Agregaralumno');
	$this->load->view('Maestras/footer');
	}

	public function Modificaralumno(){
	$this->load->view('Maestras/headermaestras');
	$this->load->view('Maestras/datosmaestra');
	$this->load->view('Maestras/modificaralumno');
	$this->load->view('Maestras/footer');
	}
	public function Bajaalumno(){
		$this->load->view('Maestras/headermaestras');
	$this->load->view('Maestras/datosmaestra');
	$this->load->view('Maestras/Bajaalumno');
	$this->load->view('Maestras/footer');
	}
	
public function Subircalificaciones(){
	$this->load->view('Maestras/headermaestras');
	$this->load->view('Maestras/datosmaestra');
	  $this->load->view('Maestras/calificaciones');
	$this->load->view('Maestras/footer');
	}

public function Subiravisos(){
	$this->load->view('Maestras/headermaestras');
	$this->load->view('Maestras/datosmaestra');
	 $this->load->view('Maestras/avisos');
	$this->load->view('Maestras/footer');   
	}

public function avisos(){
	$this->load->view('padres/headerpapas');
	$this->load->view('padres/datosalumno');
	 $this->load->view('padres/avisos');
	$this->load->view('padres/footer');
	}
	public function calificaciones(){
	$this->load->view('padres/headerpapas');
	$this->load->view('padres/datosalumno');
	$this->load->view('padres/calificaciones');
	$this->load->view('padres/footer');	
	}

	public function cuenta(){
    $this->load->view('cuenta');
	}
	public function recuperar(){
    $this->load->view('recuperar');
	}

public function iniciar()
	{
   	$u=$this->input->post('us');
	$p=$this->input->post('pas');
	$this->load->model('login');

 if($this->login->consulta($u,$p)){
	header("Location:https://sgestor.000webhostapp.com/padre");
	}
	else
	{
	if($this->login->consultam($u,$p)){	
    header("Location:https://sgestor.000webhostapp.com/maestra");
	}
	else{
	$this->load->view('login');
	}
}
}

}
?>