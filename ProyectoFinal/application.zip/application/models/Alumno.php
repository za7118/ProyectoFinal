<?php 
class Alumno extends CI_Model{
	public function Insertar($q,$w,$e,$r,$t,$y){
		$x=1;
		$querry=$this->db->query('INSERT INTO Alumno(CURP,Nombre,ApellidoP,ApellidoM,FechaN,Tutor,MAsignada)
			VALUES("'.$q.'","'.$w.'","'.$e.'","'.$r.'","'.$t.'","'.$y.'","'.$x.'")');
	}
	public function Buscar($a){
		$resultado=$this->db->query('SELECT * FROM Alumno WHERE CURP="'.$a.'"');
		return $resultado->result();
	}
	public function Eliminar($b){
		$querry=$this->db->query('DELETE FROM Alumno WHERE CURP="'.$b.'"');
	}
	public function Actualizar($d,$f,$g,$h,$j){
		$value=array('Nombre'=>$f,'ApellidoP'=>$g,'ApellidoM'=>$h,'Tutor'=>$j);
		$this->db->where('CURP',$d);
		$this->db->update('Alumno',$value);
	}
	public function Login($user,$pass){
		$this->db->where('User',$user);
		$this->db->where('Passw',$pass);
		$q=$this->db->get('Usuarios');
		if($q->num_rows()>0){
			$a=$this->db->query('SELECT Tipo_Us FROM Usuarios WHERE User="'.$user.'"');
			return $a->result();
		}
		else{
			
		}
	}
}
?>