<div class="col-sm-9 col-lg-9" style="text-align: center;">

      <!-- <img src="imagenes/bien.png" style="position:relative;left: 0px;right: 0px;top:20px;margin: auto;display: table-cell; vertical-align:middle; text-align:center;width:80%; height:80px;"> -->

<H1 style="position: relative;top: 10px;font-size: 60px;font-weight: bold;font-family: algerian;color:blue;">Bienvenido</h1>
      <p style="position: relative;top: 30px;font-size: 20px;font-weight: bold;font-family:Bell Mt;">Por favor selecciona la opción que deseas en el menú.</p>


      <!-- <img src="imagenes/imss2.jpg" > -->
    <div id="carouselExampleControls" class="carousel slide" data-ride="carousel">
  <div class="carousel-inner" style="position: relative;top: 70px;">
    <div class="carousel-item active">
      <img src="<?php echo base_url();?>Assets/imagenes/IMSS2.jpg" class="d-block w-100" alt="..." style="width: 80%;height: 200px;">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url();?>Assets/imagenes/fondoj.jpg" class="d-block w-100" alt="..." style="width: 80%;height: 250px;">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url();?>Assets/imagenes/personal.jpg" class="d-block w-100" alt="..." style="width: 80%;height: 250px;">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleControls" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleControls" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<br>
<br>
<br>
<br>
<br>
      </div>
    </div>
  </div>