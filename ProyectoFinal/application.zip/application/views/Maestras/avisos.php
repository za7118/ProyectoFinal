<div class="col-sm-9 col-lg-9" style="text-align: center;">
<H1 style="position: relative;top: 10px;font-size: 55px;font-weight: bold;font-family: algerian;color:blue;">Avisos</h1>    
<p style="position: relative;top: 5%;font-size: 20px;font-weight: bold;">Escribe un aviso para el grupo</p>
<textarea name="comentarios" rows="3" cols="50" placeholder="Escribe el aviso " style="position:relative;left: 0px;right: 0px;top:20px;"></textarea>
<br>
<input class="btn btn-primary" type='submit' value='Enviar' style="position:relative;left: 0px;right: 0px;top:20px;"/> 
</br>


<p style="position: relative;top: 7%;font-size: 20px;font-weight: bold;">Escribe un aviso solo para un alumno</p> 
</br>
<label style="position:relative;left: 0px;right: 0px;top:10px;">
    <select>
        <option selected>Selecciona</option>
    </select>
</label>
<br>
<textarea name="comentarios" rows="3" cols="50" placeholder="Escribe el aviso " style="position:relative;left: 0px;right: 0px;top:20px;"></textarea>
<br>
<input class="btn btn-primary" type='submit' value='Enviar' style="position:relative;left: 0px;right: 0px;top:20px;"/> 

<br>
<br>
<br>
<br>
<br>
      </div>
    </div>
  </div>