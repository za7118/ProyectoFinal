 <div class="col-sm-9 col-lg-9" style="text-align: center;">
<H1 style="position: relative;top: 10px;font-size: 50px;font-weight: bold;font-family: algerian;color:blue;">Calificaciones</h1>    
<p style="position: relative;top: 10%;font-size: 20px;font-weight: bold;">Selecciona el alumno</p> 
</br>
<label style="position:relative;left: 0px;right: 0px;top:20px;">
    <select>
        <option selected>Selecciona</option>
    </select>
</label>

<p style="position: relative;top: 40px;font-size: 20px;font-weight: bold;">Selecciona el periodo</p> 
</br>
<label style="position:relative;left: 0px;right: 0px;top:5px;">
    <select>
        <option selected>Selecciona</option>
        <option>Primer perdiodo</option>
        <option>Segundo perido</option>
        <option>Tercer perido</option>
    </select>
</label>
<br>
<input  type='file'  style="position:relative;left: 0px;right: 0px;top:20px;"/>
</br>
<br>
<input class="btn btn-primary" type='submit' value='Subir evaluación' style="position:relative;left: 0px;right: 0px;top:20px;"/>
<br>
<br>
<br>
<br>
<br>
<br>
      </div>
    </div>
  </div>