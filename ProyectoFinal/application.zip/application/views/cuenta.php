 <div class="col-sm-9 col-lg-9" style="text-align: center;">
<H1 style="position: relative;top: 10px;font-size: 55px;font-weight: bold;font-family: algerian;color:blue;">CUENTA</h1>    
<p style="position: relative;top: 3%;font-size: 20px;font-weight: bold;">Cambia tu contraseña por una nueva</p> 
<br>


<div class="nav-tabs-responsive">
  <div class="card">
    <ul class="nav nav-tabs">
      <li class="nav-item">
        <a href="#account" class="nav-link active" data-toggle="tab">
          <i class="fa fa-lock mr-2"></i>Cuenta
        </a>
      </li>
    </ul>
    <div id="tabContent" class="tab-content">
      <div id="account" class="tab-pane show active">
        <a href="#account-collapse" class="nav-link-collapse" data-toggle="collapse">
          <i class="fa fa-lock mr-2"></i>Datos cuenta
        </a>
        <div id="account-collapse" class="collapse show" data-parent="#tabContent">
          <div class="card-body">
            <form style="position: relative;top:20px;">
              <div class="form-row">
                <form>
    <div class="form-group col-md-6" style="text-align: left;">
      <label for="inputEmail4"> Usuario:</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Nombre completo"  readonly="readonly">
    </div>
    <div class="form-group col-md-6" style="text-align: left;">
      <label for="inputEmail4"> Nueva contraseña:</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Ingresa contraseña" required="">
    </div>
  </div>
</form>

<br>
  <div class="form-row">
    <div class="form-group col-md-6" style="text-align: left;">
      <label for="inputEmail4">Contraseña actual:</label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Ingresa contraseña" required="">
    </div>
    <div class="form-group col-md-6" style="text-align: left;">
      <label for="inputPassword4">Repetir nueva contraseña:</label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="Ingresa contraseña" required="">
    </div>
  </div>


<!-- findatos -->
          </div>
        </div>
      </div>

      </div>
      </div>
<div class="form-group">
  <br>
  <button type="submit" class="btn btn-primary mr-1">
   Guardar
  </button>
  <button type="button" class="btn btn-secondary">
    Cancelar
  </button>
</form>
</div>
<br>
<br>
<br>
<br>
<br>
<br>
      </div>
    </div>
  </div>
</div>