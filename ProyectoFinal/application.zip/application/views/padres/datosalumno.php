  <div class="container-fluid" style="height: 100%;">
    <div class="row" >
      <div class="col-sm-3 col-lg-3" style="">
        <br></br>
        <div class="card" style="background-color: #90CAF9;">
  <img src="<?php echo base_url();?>Assets/imagenes/persona.png"  width="70%" height="200" position="center" style="display:block; margin-left: auto;
  margin-right: auto;">
  <div class="card-body">
    <h5 class="card-title" style="font-family: arial black;font-size: 15px;">DATOS DEL ESTUDIANTE</h5>
    <p class="card-text" style="font-family: bz-modeler-font;">NOMBRE:</p>
    <p class="card-text" style="font-family: bz-modeler-font;">APELLIDOS:</p>
    <p class="card-text" style="font-family: bz-modeler-font;">GRADO:</p>
    <p class="card-text" style="font-family: bz-modeler-font;">GRUPO:</p>
    <p class="card-text" style="font-family: bz-modeler-font;">MAESTRA:</p>
  </div>
</div>
      <br>
</div>