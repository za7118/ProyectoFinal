<!doctype html>
<html lang="en" style=" min-height: 100%;position: relative;">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css" integrity="sha384-GJzZqFGwb1QTTN6wy59ffF1BuGJpLSa9DkKMp0DgiMDm4iYMj70gZWKYbI706tWS" crossorigin="anonymous">
    <title>Bienvenido</title>
    <style type="text/css">
      body{
        display: flex;
         min-height: 100vh;
        flex-wrap: wrap;
      }
      #f{
        align-self: flex-end;
       
      }
     
    </style>
  </head>

  <body style="background-image: url(<?php echo base_url();?>Assets/imagenes/fp.png);background-repeat:no-repeat;background-size: 100% 100%;">

  <div class="container-fluid" style="height: 100%;">
    <div class="row" >
    <div class="form-group col-md-12" style="text-align: center;">
      <H1 style="position: relative;top: 50px;font-size: 55px;font-weight: bold;font-family: algerian;color:blue;">Recuperar contraseña </h1>
        <form style="position: relative;top:60px;">
      <p style="position: relative;top: 5%;font-size: 20px;font-weight: bold;">Ingresa tu correo electronico:</p>
      <input type="email" class="form-control" id="inputEmail4" placeholder="Correo electronico" required="" style="width: 400px;position: relative;top: 0px;left: 0px;right: 0px; margin-left: auto;margin-right: auto;">
      <br>

      <input type="Submit" class="btn btn-primary" style="width: 200px;position: relative;top: 0px;left: 0px;right: 0px; margin-left: auto;margin-right: auto;">
      <br>
      <br>
      <input type="button" class="btn btn-primary"  value="Regresar" style="width: 150px;position: relative;top: 0px;left: 0px;right: 0px; margin-left: auto;margin-right: auto;">
      </form>
    </div>
      </div>
    </div>

  <div class="container-fluid" id="f" style="with:100%;height:15%;background-color:#505055;color:white;font-family:Calibri Light;font-weight: bold;">
    <div class="row">
  <div class="col-sm-4 col-lg-4"  style="text-align: center;font-family:Bahnschrift;">
<br>MA.CONCEPCION ALVAREZ PEREZ</br>
<br>DIRECTORA</br>
</div>
<div class="col-sm-4 col-lg-4" style="text-align: center;font-family:Bahnschrift;">
<br>CALLE 15 S/N</br>
<br>FRAY BERNARDINO DE SAHAGÚN</br>
</div>
<div class="col-sm-4 col-lg-4" style="text-align: center;font-family:Bahnschrift;">
<br>TELÉFONO 9130152</br>
<br>CÓDIGO POSTAL 43995</br>

</div>
    </div>
  </div>
 


    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js" integrity="sha384-B0UglyR+jN6CkvvICOB2joaf5I4l3gm9GU6Hc1og6Ls7i6U/mkkaduKaBhlAXv9k" crossorigin="anonymous"></script>

  </body>
</html>